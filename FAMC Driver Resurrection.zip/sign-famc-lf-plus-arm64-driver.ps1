# FAMC LF+ / FTDI Windows 11 ARM64 Driver Signing Script
# Target driver folder:
# C:\Program Files\FAMC\Drivers\ARM64\Image
#
# Run in PowerShell as Administrator.

$ErrorActionPreference = "Stop"

$BasePath   = "C:\Program Files\FAMC\Drivers\ARM64"
$DriverPath = "C:\Program Files\FAMC\Drivers\ARM64\Image"
$X86Path    = "C:\Program Files\FAMC\Drivers\ARM64\x86"

$CertName    = "FAMC LF Plus ARM64 Test Driver"
$CertSubject = "CN=$CertName"

Write-Host ""
Write-Host "========================================"
Write-Host " FAMC LF+ ARM64 Driver Signing Script"
Write-Host "========================================"
Write-Host ""

# ------------------------------------------------------------
# 1. Check Administrator mode
# ------------------------------------------------------------

$principal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())

if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    throw "This script must be run as Administrator."
}

Write-Host "Admin check: OK"
Write-Host ""

# ------------------------------------------------------------
# 2. Check expected folders
# ------------------------------------------------------------

if (-not (Test-Path $BasePath)) {
    throw "Base folder not found: $BasePath"
}

if (-not (Test-Path $DriverPath)) {
    throw "Driver Image folder not found: $DriverPath"
}

Set-Location $DriverPath

Write-Host "Base folder:"
Write-Host $BasePath
Write-Host ""

Write-Host "Driver Image folder:"
Write-Host $DriverPath
Write-Host ""

if (Test-Path $X86Path) {
    Write-Host "x86 helper folder found:"
    Write-Host $X86Path
    Write-Host "Note: this script does not modify the x86 folder."
    Write-Host ""
}

# ------------------------------------------------------------
# 3. Check required INF files
# ------------------------------------------------------------

$BusInf  = Join-Path $DriverPath "ftdibus.inf"
$PortInf = Join-Path $DriverPath "ftdiport.inf"

if (-not (Test-Path $BusInf)) {
    throw "Missing ftdibus.inf in: $DriverPath"
}

if (-not (Test-Path $PortInf)) {
    throw "Missing ftdiport.inf in: $DriverPath"
}

Write-Host "Required INF files found:"
Write-Host "ftdibus.inf"
Write-Host "ftdiport.inf"
Write-Host ""

# ------------------------------------------------------------
# 4. Add ARM64 CatalogFile entries if missing
# ------------------------------------------------------------

function Add-Arm64CatalogLine {
    param (
        [string]$InfPath,
        [string]$CatName
    )

    $fileName = Split-Path $InfPath -Leaf
    $lines = Get-Content $InfPath

    if ($lines -match '^CatalogFile\.ntarm64\s*=') {
        Write-Host "$fileName already has CatalogFile.ntarm64"
        return
    }

    $catalogLine = Select-String -Path $InfPath -Pattern '^CatalogFile' | Select-Object -First 1

    if ($null -eq $catalogLine) {
        throw "No CatalogFile line found in $fileName"
    }

    $insertAfter = $catalogLine.LineNumber
    $newLines = @()

    for ($i = 0; $i -lt $lines.Count; $i++) {
        $newLines += $lines[$i]

        if (($i + 1) -eq $insertAfter) {
            $newLines += "CatalogFile.ntarm64 = $CatName"
        }
    }

    Set-Content -Path $InfPath -Value $newLines -Encoding ASCII
    Write-Host "Added CatalogFile.ntarm64 = $CatName to $fileName"
}

Add-Arm64CatalogLine $BusInf "ftdibus.cat"
Add-Arm64CatalogLine $PortInf "ftdiport.cat"

Write-Host ""

# ------------------------------------------------------------
# 5. Locate Windows SDK / WDK tools
# ------------------------------------------------------------

$KitRoot = "${env:ProgramFiles(x86)}\Windows Kits\10\bin"

if (-not (Test-Path $KitRoot)) {
    throw "Windows Kits path not found. Is the Windows 11 SDK/WDK installed?"
}

$inf2catItem = Get-ChildItem $KitRoot -Recurse -Filter inf2cat.exe -ErrorAction SilentlyContinue |
    Where-Object { $_.FullName -match '\\10\.\d+\.\d+\.\d+\\(x64|x86)\\inf2cat\.exe$' } |
    Sort-Object FullName -Descending |
    Select-Object -First 1

$signtoolItem = Get-ChildItem $KitRoot -Recurse -Filter signtool.exe -ErrorAction SilentlyContinue |
    Where-Object { $_.FullName -match '\\10\.\d+\.\d+\.\d+\\(x64|x86)\\signtool\.exe$' } |
    Sort-Object FullName -Descending |
    Select-Object -First 1

if ($null -eq $inf2catItem) {
    throw "inf2cat.exe not found. Install the Windows 11 WDK."
}

if ($null -eq $signtoolItem) {
    throw "signtool.exe not found. Install the Windows 11 SDK."
}

$inf2cat = $inf2catItem.FullName
$signtool = $signtoolItem.FullName

Write-Host "WDK tools found:"
Write-Host "inf2cat:  $inf2cat"
Write-Host "signtool: $signtool"
Write-Host ""

# ------------------------------------------------------------
# 6. Generate ARM64 catalog files
# ------------------------------------------------------------

Write-Host "Generating ARM64 catalog files..."
& $inf2cat /driver:"$DriverPath" /os:10_GE_ARM64

if ($LASTEXITCODE -ne 0) {
    throw "inf2cat failed. Catalog files were not generated successfully."
}

Write-Host ""
Write-Host "Catalog generation: OK"
Write-Host ""

# ------------------------------------------------------------
# 7. Create or reuse generic test-signing certificate
# ------------------------------------------------------------

$existingCert = Get-ChildItem "Cert:\LocalMachine\My" |
    Where-Object { $_.Subject -eq $CertSubject } |
    Sort-Object NotAfter -Descending |
    Select-Object -First 1

if ($null -ne $existingCert) {
    $cert = $existingCert
    Write-Host "Reusing existing certificate:"
    Write-Host $cert.Subject
} else {
    Write-Host "Creating new test-signing certificate..."

    $cert = New-SelfSignedCertificate `
        -Type CodeSigningCert `
        -Subject $CertSubject `
        -CertStoreLocation "Cert:\LocalMachine\My" `
        -KeyUsage DigitalSignature `
        -KeyAlgorithm RSA `
        -KeyLength 2048 `
        -HashAlgorithm SHA256 `
        -NotAfter (Get-Date).AddYears(10)

    Write-Host "Certificate created."
}

$thumbprint = $cert.Thumbprint
$thumbprintFile = Join-Path $BasePath "famc-lf-plus-arm64-cert-thumbprint.txt"
$thumbprint | Out-File $thumbprintFile -Encoding ASCII

Write-Host ""
Write-Host "Certificate name:"
Write-Host $CertName
Write-Host ""
Write-Host "Certificate thumbprint:"
Write-Host $thumbprint
Write-Host ""

# ------------------------------------------------------------
# 8. Export and trust certificate locally
# ------------------------------------------------------------

$CertFile = Join-Path $BasePath "FAMC-LF-Plus-ARM64-Test-Driver.cer"

Export-Certificate -Cert $cert -FilePath $CertFile | Out-Null

& certutil.exe -addstore -f "Root" "$CertFile"

if ($LASTEXITCODE -ne 0) {
    throw "Failed to import certificate into LocalMachine Root store."
}

& certutil.exe -addstore -f "TrustedPublisher" "$CertFile"

if ($LASTEXITCODE -ne 0) {
    throw "Failed to import certificate into LocalMachine TrustedPublisher store."
}

Write-Host "Certificate exported to:"
Write-Host $CertFile
Write-Host ""

Write-Host "Certificate imported into:"
Write-Host "LocalMachine\Root"
Write-Host "LocalMachine\TrustedPublisher"
Write-Host ""

# ------------------------------------------------------------
# 9. Sign catalog files
# ------------------------------------------------------------

$BusCat  = Join-Path $DriverPath "ftdibus.cat"
$PortCat = Join-Path $DriverPath "ftdiport.cat"

if (-not (Test-Path $BusCat)) {
    throw "Missing ftdibus.cat after inf2cat."
}

if (-not (Test-Path $PortCat)) {
    throw "Missing ftdiport.cat after inf2cat."
}

Write-Host "Signing ftdibus.cat..."
& $signtool sign /v /fd SHA256 /sm /s My /sha1 $thumbprint "$BusCat"

if ($LASTEXITCODE -ne 0) {
    throw "Signing failed for ftdibus.cat"
}

Write-Host ""
Write-Host "Signing ftdiport.cat..."
& $signtool sign /v /fd SHA256 /sm /s My /sha1 $thumbprint "$PortCat"

if ($LASTEXITCODE -ne 0) {
    throw "Signing failed for ftdiport.cat"
}

Write-Host ""
Write-Host "Signing: OK"
Write-Host ""

# ------------------------------------------------------------
# 10. Verify signatures
# ------------------------------------------------------------

Write-Host "Verifying ftdibus.cat..."
& $signtool verify /v /pa "$BusCat"

if ($LASTEXITCODE -ne 0) {
    throw "Verification failed for ftdibus.cat"
}

Write-Host ""
Write-Host "Verifying ftdiport.cat..."
& $signtool verify /v /pa "$PortCat"

if ($LASTEXITCODE -ne 0) {
    throw "Verification failed for ftdiport.cat"
}

Write-Host ""
Write-Host "Signature verification: OK"
Write-Host ""

# ------------------------------------------------------------
# 11. Enable Windows test-signing mode
# ------------------------------------------------------------

Write-Host "Enabling Windows test-signing mode..."
bcdedit /set testsigning on

if ($LASTEXITCODE -ne 0) {
    Write-Host ""
    Write-Host "Test-signing could not be enabled."
    Write-Host "This usually means Secure Boot is still enabled in Parallels."
    Write-Host ""
    Write-Host "Fix:"
    Write-Host "1. Shut down the Windows VM."
    Write-Host "2. Open the VM configuration in Parallels."
    Write-Host "3. Disable Secure Boot."
    Write-Host "4. Boot Windows again."
    Write-Host "5. Rerun this script."
    Write-Host ""
    throw "bcdedit failed."
}

Write-Host ""
Write-Host "Test-signing command accepted."
Write-Host ""

# ------------------------------------------------------------
# 12. Optional immediate install
# ------------------------------------------------------------

Write-Host "========================================"
Write-Host " Signing complete"
Write-Host "========================================"
Write-Host ""
Write-Host "The ARM64 driver package is now signed."
Write-Host ""
Write-Host "Signed driver folder:"
Write-Host $DriverPath
Write-Host ""
Write-Host "IMPORTANT:"
Write-Host "If this is the first time enabling test-signing, reboot Windows before installing the driver."
Write-Host ""

Write-Host "After reboot, the install commands are:"
Write-Host ""
Write-Host "cd `"$DriverPath`""
Write-Host "pnputil /add-driver `".\ftdibus.inf`" /install"
Write-Host "pnputil /add-driver `".\ftdiport.inf`" /install"
Write-Host ""

$installNow = Read-Host "Install the driver now anyway? Type YES to install now, or press Enter to skip"

if ($installNow -eq "YES") {
    Write-Host ""
    Write-Host "Installing ftdibus.inf..."
    pnputil /add-driver ".\ftdibus.inf" /install

    Write-Host ""
    Write-Host "Installing ftdiport.inf..."
    pnputil /add-driver ".\ftdiport.inf" /install

    Write-Host ""
    Write-Host "Driver install commands completed."
    Write-Host ""
    Write-Host "Reconnect the LF+ device and check Device Manager."
} else {
    Write-Host ""
    Write-Host "Install skipped."
}

Write-Host ""
Write-Host "Expected Device Manager entries after successful install:"
Write-Host "FAMC LF Controller"
Write-Host "FAMC LF+ Series (COMx)"
Write-Host ""
Write-Host "Done."