# FAMC LF+ / FTDI ARM64 INF Patch Script
# Converts the official FTDI ARM64 ftdibus.inf and ftdiport.inf files
# into the same FAMC-compatible INF structure as the known working converted files.
#
# Expected layout:
#
# ARM64
# ├── patch-famc-lf-plus-inf-files.ps1
# ├── sign-famc-lf-plus-arm64-driver.ps1
# ├── Image
# │   ├── ftdibus.inf
# │   └── ftdiport.inf
# └── x86
#
# Run in PowerShell as Administrator.

$ErrorActionPreference = "Stop"

$BasePath   = Split-Path -Parent $MyInvocation.MyCommand.Path
$DriverPath = Join-Path $BasePath "Image"

$BusInf  = Join-Path $DriverPath "ftdibus.inf"
$PortInf = Join-Path $DriverPath "ftdiport.inf"

$FamcPids = @("87C0", "87C1", "87C2", "87C3", "87C4", "87C5", "87C6")

Write-Host ""
Write-Host "========================================"
Write-Host " FAMC LF+ INF Patch Script"
Write-Host "========================================"
Write-Host ""

# ------------------------------------------------------------
# Check Administrator mode
# ------------------------------------------------------------

$principal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())

if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    throw "This script must be run as Administrator."
}

Write-Host "Admin check: OK"
Write-Host ""

# ------------------------------------------------------------
# Check expected files
# ------------------------------------------------------------

if (-not (Test-Path $DriverPath)) {
    throw "Driver Image folder not found: $DriverPath"
}

if (-not (Test-Path $BusInf)) {
    throw "Missing ftdibus.inf in: $DriverPath"
}

if (-not (Test-Path $PortInf)) {
    throw "Missing ftdiport.inf in: $DriverPath"
}

Write-Host "Driver Image folder:"
Write-Host $DriverPath
Write-Host ""

Write-Host "Found:"
Write-Host "ftdibus.inf"
Write-Host "ftdiport.inf"
Write-Host ""

# ------------------------------------------------------------
# Backup originals once
# ------------------------------------------------------------

function Backup-Once {
    param (
        [string]$Path
    )

    $backupPath = "$Path.original-ftdi-backup"

    if (-not (Test-Path $backupPath)) {
        Copy-Item $Path $backupPath
        Write-Host "Created backup: $(Split-Path $backupPath -Leaf)"
    } else {
        Write-Host "Backup already exists: $(Split-Path $backupPath -Leaf)"
    }
}

Backup-Once $BusInf
Backup-Once $PortInf

Write-Host ""

# ------------------------------------------------------------
# Helper functions
# ------------------------------------------------------------

function Get-InfLinesWithoutLongHeader {
    param (
        [string]$InfPath
    )

    $lines = Get-Content $InfPath

    if ($lines.Count -eq 0) {
        throw "INF file is empty: $InfPath"
    }

    $versionIndex = -1

    for ($i = 0; $i -lt $lines.Count; $i++) {
        if ($lines[$i].Trim() -ieq "[Version]") {
            $versionIndex = $i
            break
        }
    }

    if ($versionIndex -lt 0) {
        throw "No [Version] section found in: $InfPath"
    }

    # The known working converted files keep only the first title comment,
    # then begin at [Version]. This intentionally strips the long FTDI licence
    # comment block from the local generated INF file.
    $newLines = @()
    $newLines += $lines[0].TrimEnd()
    $newLines += ""

    for ($i = $versionIndex; $i -lt $lines.Count; $i++) {
        $newLines += $lines[$i]
    }

    return $newLines
}

function Replace-SectionBody {
    param (
        [string[]]$Lines,
        [string]$SectionName,
        [string[]]$NewBody
    )

    $sectionHeader = "[$SectionName]"
    $start = -1

    for ($i = 0; $i -lt $Lines.Count; $i++) {
        if ($Lines[$i].Trim() -ieq $sectionHeader) {
            $start = $i
            break
        }
    }

    if ($start -lt 0) {
        throw "Section [$SectionName] not found."
    }

    $end = $Lines.Count

    for ($i = $start + 1; $i -lt $Lines.Count; $i++) {
        if ($Lines[$i].Trim() -match '^\[.+\]$') {
            $end = $i
            break
        }
    }

    $result = @()

    if ($start -gt 0) {
        $result += $Lines[0..$start]
    } else {
        $result += $Lines[$start]
    }

    $result += $NewBody

    if ($end -lt $Lines.Count) {
        $result += $Lines[$end..($Lines.Count - 1)]
    }

    return $result
}

function Replace-Catalog-Line {
    param (
        [string[]]$Lines,
        [string]$CatalogName
    )

    $out = foreach ($line in $Lines) {
        if ($line -match '^CatalogFile\s*=') {
            "CatalogFile.NTARM64=$CatalogName"
        } elseif ($line -match '^CatalogFile\.NTARM64\s*=') {
            "CatalogFile.NTARM64=$CatalogName"
        } elseif ($line -match '^CatalogFile\.ntarm64\s*=') {
            "CatalogFile.NTARM64=$CatalogName"
        } else {
            $line
        }
    }

    return $out
}

function Write-InfAscii {
    param (
        [string]$Path,
        [string[]]$Lines
    )

    # Set-Content adds normal Windows line endings in Windows PowerShell.
    Set-Content -Path $Path -Value $Lines -Encoding ASCII
}

# ------------------------------------------------------------
# Patch ftdibus.inf
# ------------------------------------------------------------

Write-Host "Patching ftdibus.inf..."
Write-Host ""

$busLines = Get-InfLinesWithoutLongHeader -InfPath $BusInf
$busLines = Replace-Catalog-Line -Lines $busLines -CatalogName "ftdibus.cat"

$busHwLines = @(
    "%USB\VID_0403&PID_6001.DeviceDesc%=FtdiBus.NT,USB\VID_0403&PID_6001",
    "%USB\VID_0403&PID_6015.DeviceDesc%=FtdiBus.NT,USB\VID_0403&PID_6015",
    "%USB\VID_0403&PID_87C0.DeviceDesc%=FtdiBus.NT,USB\VID_0403&PID_87C0",
    "%USB\VID_0403&PID_87C1.DeviceDesc%=FtdiBus.NT,USB\VID_0403&PID_87C1",
    "%USB\VID_0403&PID_87C2.DeviceDesc%=FtdiBus.NT,USB\VID_0403&PID_87C2",
    "%USB\VID_0403&PID_87C3.DeviceDesc%=FtdiBus.NT,USB\VID_0403&PID_87C3",
    "%USB\VID_0403&PID_87C4.DeviceDesc%=FtdiBus.NT,USB\VID_0403&PID_87C4",
    "%USB\VID_0403&PID_87C5.DeviceDesc%=FtdiBus.NT,USB\VID_0403&PID_87C5",
    "%USB\VID_0403&PID_87C6.DeviceDesc%=FtdiBus.NT,USB\VID_0403&PID_87C6",
    ""
)

$busStringLines = @(
    'Ftdi="FAMC"',
    'DESC="CDM Driver Package - Bus/D2XX Driver"',
    'DriversDisk="FTDI USB Drivers Disk"',
    'USB\VID_0403&PID_6001.DeviceDesc="USB Serial Converter"',
    'USB\VID_0403&PID_6015.DeviceDesc="USB Serial Converter"',
    'USB\VID_0403&PID_87C0.DeviceDesc="FAMC LF Controller"',
    'USB\VID_0403&PID_87C1.DeviceDesc="FAMC LR Controller"',
    'USB\VID_0403&PID_87C2.DeviceDesc="FAMC X Series Controller"',
    'USB\VID_0403&PID_87C3.DeviceDesc="FAMC Controller"',
    'USB\VID_0403&PID_87C4.DeviceDesc="FAMC Controller"',
    'USB\VID_0403&PID_87C5.DeviceDesc="FAMC Controller"',
    'USB\VID_0403&PID_87C6.DeviceDesc="FAMC Controller"',
    'SvcDesc="USB Serial Converter Driver"',
    'ClassName="USB"'
)

$busLines = Replace-SectionBody -Lines $busLines -SectionName "FtdiHw.NTARM64" -NewBody $busHwLines
$busLines = Replace-SectionBody -Lines $busLines -SectionName "Strings" -NewBody $busStringLines

Write-InfAscii -Path $BusInf -Lines $busLines

Write-Host "ftdibus.inf patched."
Write-Host ""

# ------------------------------------------------------------
# Patch ftdiport.inf
# ------------------------------------------------------------

Write-Host "Patching ftdiport.inf..."
Write-Host ""

$portLines = Get-InfLinesWithoutLongHeader -InfPath $PortInf
$portLines = Replace-Catalog-Line -Lines $portLines -CatalogName "ftdiport.cat"

$portHwLines = @(
    "%VID_0403&PID_6001.DeviceDesc%=FtdiPort.NT,FTDIBUS\COMPORT&VID_0403&PID_6001",
    "%VID_0403&PID_6015.DeviceDesc%=FtdiPort.NT,FTDIBUS\COMPORT&VID_0403&PID_6015",
    "%VID_0403&PID_87C0.DeviceDesc%=FtdiPort.NT,FTDIBUS\COMPORT&VID_0403&PID_87C0",
    "%VID_0403&PID_87C1.DeviceDesc%=FtdiPort.NT,FTDIBUS\COMPORT&VID_0403&PID_87C1",
    "%VID_0403&PID_87C2.DeviceDesc%=FtdiPort.NT,FTDIBUS\COMPORT&VID_0403&PID_87C2",
    "%VID_0403&PID_87C3.DeviceDesc%=FtdiPort.NT,FTDIBUS\COMPORT&VID_0403&PID_87C3",
    "%VID_0403&PID_87C4.DeviceDesc%=FtdiPort.NT,FTDIBUS\COMPORT&VID_0403&PID_87C4",
    "%VID_0403&PID_87C5.DeviceDesc%=FtdiPort.NT,FTDIBUS\COMPORT&VID_0403&PID_87C5",
    "%VID_0403&PID_87C6.DeviceDesc%=FtdiPort.NT,FTDIBUS\COMPORT&VID_0403&PID_87C6",
    ""
)

$portStringLines = @(
    'FTDI="FAMC"',
    'DESC="CDM Driver Package - VCP Driver"',
    'DriversDisk="FTDI USB Drivers Disk"',
    'PortsClassName = "Ports (COM & LPT)"',
    'VID_0403&PID_6001.DeviceDesc="USB Serial Port"',
    'VID_0403&PID_6015.DeviceDesc="USB Serial Port"',
    'VID_0403&PID_87C0.DeviceDesc="FAMC LF+ Series"',
    'VID_0403&PID_87C1.DeviceDesc="FAMC LR Series"',
    'VID_0403&PID_87C2.DeviceDesc="FAMC X Series"',
    'VID_0403&PID_87C3.DeviceDesc="FAMC Device"',
    'VID_0403&PID_87C4.DeviceDesc="FAMC Device"',
    'VID_0403&PID_87C5.DeviceDesc="FAMC Device"',
    'VID_0403&PID_87C6.DeviceDesc="FAMC Device"',
    'SvcDesc="USB Serial Port Driver"',
    'SerEnum.SvcDesc="Serenum Filter Driver"',
    ""
)

$portLines = Replace-SectionBody -Lines $portLines -SectionName "FtdiHw.NTARM64" -NewBody $portHwLines
$portLines = Replace-SectionBody -Lines $portLines -SectionName "Strings" -NewBody $portStringLines

Write-InfAscii -Path $PortInf -Lines $portLines

Write-Host "ftdiport.inf patched."
Write-Host ""

# ------------------------------------------------------------
# Verification
# ------------------------------------------------------------

Write-Host "Verifying patched content..."
Write-Host ""

$busRequired = @(
    "CatalogFile.NTARM64=ftdibus.cat",
    "%USB\VID_0403&PID_87C0.DeviceDesc%=FtdiBus.NT,USB\VID_0403&PID_87C0",
    "%USB\VID_0403&PID_87C1.DeviceDesc%=FtdiBus.NT,USB\VID_0403&PID_87C1",
    "%USB\VID_0403&PID_87C2.DeviceDesc%=FtdiBus.NT,USB\VID_0403&PID_87C2",
    "%USB\VID_0403&PID_87C3.DeviceDesc%=FtdiBus.NT,USB\VID_0403&PID_87C3",
    "%USB\VID_0403&PID_87C4.DeviceDesc%=FtdiBus.NT,USB\VID_0403&PID_87C4",
    "%USB\VID_0403&PID_87C5.DeviceDesc%=FtdiBus.NT,USB\VID_0403&PID_87C5",
    "%USB\VID_0403&PID_87C6.DeviceDesc%=FtdiBus.NT,USB\VID_0403&PID_87C6",
    'Ftdi="FAMC"'
)

$portRequired = @(
    "CatalogFile.NTARM64=ftdiport.cat",
    "%VID_0403&PID_87C0.DeviceDesc%=FtdiPort.NT,FTDIBUS\COMPORT&VID_0403&PID_87C0",
    "%VID_0403&PID_87C1.DeviceDesc%=FtdiPort.NT,FTDIBUS\COMPORT&VID_0403&PID_87C1",
    "%VID_0403&PID_87C2.DeviceDesc%=FtdiPort.NT,FTDIBUS\COMPORT&VID_0403&PID_87C2",
    "%VID_0403&PID_87C3.DeviceDesc%=FtdiPort.NT,FTDIBUS\COMPORT&VID_0403&PID_87C3",
    "%VID_0403&PID_87C4.DeviceDesc%=FtdiPort.NT,FTDIBUS\COMPORT&VID_0403&PID_87C4",
    "%VID_0403&PID_87C5.DeviceDesc%=FtdiPort.NT,FTDIBUS\COMPORT&VID_0403&PID_87C5",
    "%VID_0403&PID_87C6.DeviceDesc%=FtdiPort.NT,FTDIBUS\COMPORT&VID_0403&PID_87C6",
    'FTDI="FAMC"'
)

$busText = Get-Content $BusInf -Raw
$portText = Get-Content $PortInf -Raw

foreach ($required in $busRequired) {
    if ($busText -notlike "*$required*") {
        throw "Verification failed for ftdibus.inf. Missing: $required"
    }
}

foreach ($required in $portRequired) {
    if ($portText -notlike "*$required*") {
        throw "Verification failed for ftdiport.inf. Missing: $required"
    }
}

Write-Host "Verified FAMC device IDs:"
foreach ($pid in $FamcPids) {
    Write-Host "VID_0403&PID_$pid"
}

Write-Host ""
Write-Host "========================================"
Write-Host " INF patch complete"
Write-Host "========================================"
Write-Host ""
Write-Host "Next step:"
Write-Host "Run the signing script:"
Write-Host ""
Write-Host "cd `"$BasePath`""
Write-Host ".\sign-famc-lf-plus-arm64-driver.ps1"
Write-Host ""
